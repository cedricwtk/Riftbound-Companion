# Trades Screen Integration Guide

## 1. Install the new dependency

```bash
npx expo install expo-notifications
```

---

## 2. Add TradesScreen.js to your project

Copy `TradesScreen.js` → `src/screens/TradesScreen.js`

---

## 3. Update AppNavigator.js

Add the Trades tab to your bottom navigator:

```js
import TradesScreen from '../screens/TradesScreen';

// Inside your Tab.Navigator, add:
<Tab.Screen
  name="Trades"
  component={TradesScreen}
  options={{
    tabBarLabel: 'Trades',
    tabBarIcon: ({ color, size }) => (
      <Ionicons name="swap-horizontal-outline" color={color} size={size} />
    ),
  }}
/>
```

---

## 4. Update app.json

Add notification permissions inside the `expo` block:

```json
"plugins": [
  [
    "expo-notifications",
    {
      "icon": "./assets/icon.png",
      "color": "#ffffff"
    }
  ]
],
"android": {
  "permissions": ["RECEIVE_BOOT_COMPLETED", "VIBRATE", "POST_NOTIFICATIONS"]
}
```

---

## 5. Update theme.js

Make sure these color keys exist (add if missing):

```js
export const COLORS = {
  // ... your existing colors ...
  win: '#4CAF50',       // green — used for "Completed" status
  danger: '#E05252',    // red  — used for "Cancelled" status
  bgInput: '#1a1a2e',   // dark input background
  bgElevated: '#16213e',
};
```

---

## Features included

- **Trade list** with status filter (All / Upcoming / Completed / Cancelled)
- **Create/edit trades** with trader name, date, time, place, notes
- **Card browser integration** — tap "Browse & Add Cards" to pick from your full card list
- **Push notification** scheduled automatically 1 day before meetup
- **Mark as Completed / Cancelled** from the detail view
- **Persistent storage** via AsyncStorage
