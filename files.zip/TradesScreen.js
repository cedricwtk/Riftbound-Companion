import React, { useState, useEffect } from 'react';
import {
  View, Text, StyleSheet, FlatList, TouchableOpacity,
  TextInput, Modal, ScrollView, Alert, Platform
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import * as Notifications from 'expo-notifications';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { COLORS, SPACING, RADIUS } from '../utils/theme';
import CardsScreen from './CardsScreen';

// ── Notification setup ───────────────────────────────────────────────────────
Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: false,
  }),
});

const requestNotificationPermission = async () => {
  const { status } = await Notifications.requestPermissionsAsync();
  return status === 'granted';
};

const scheduleTradReminder = async (trade) => {
  if (!trade.meetupDate) return null;
  const meetup = new Date(trade.meetupDate);
  const reminder = new Date(meetup.getTime() - 24 * 60 * 60 * 1000); // 1 day before
  if (reminder <= new Date()) return null;

  const id = await Notifications.scheduleNotificationAsync({
    content: {
      title: '📦 Trade Reminder!',
      body: `You're trading with ${trade.traderName} tomorrow${trade.meetupPlace ? ` at ${trade.meetupPlace}` : ''}!`,
      data: { tradeId: trade.id },
    },
    trigger: { date: reminder },
  });
  return id;
};

const cancelTradeNotification = async (notificationId) => {
  if (notificationId) {
    await Notifications.cancelScheduledNotificationAsync(notificationId);
  }
};

// ── Storage ───────────────────────────────────────────────────────────────────
const TRADES_KEY = 'riftbound_trades';

const getTrades = async () => {
  try {
    const raw = await AsyncStorage.getItem(TRADES_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch { return []; }
};

const saveTrades = async (trades) => {
  await AsyncStorage.setItem(TRADES_KEY, JSON.stringify(trades));
};

// ── Status badge ─────────────────────────────────────────────────────────────
const STATUS_COLORS = {
  upcoming: COLORS.arcaneBright,
  completed: COLORS.win,
  cancelled: COLORS.danger,
};

const StatusBadge = ({ status }) => (
  <View style={[styles.statusBadge, { backgroundColor: STATUS_COLORS[status] + '33', borderColor: STATUS_COLORS[status] }]}>
    <Text style={[styles.statusText, { color: STATUS_COLORS[status] }]}>
      {status.toUpperCase()}
    </Text>
  </View>
);

// ── Trade card list item ──────────────────────────────────────────────────────
const TradeCardItem = ({ card, onRemove }) => (
  <View style={styles.tradeCardItem}>
    <View style={[styles.tradeCardDot, { backgroundColor: COLORS.arcaneBright }]} />
    <Text style={styles.tradeCardName} numberOfLines={1}>{card.name}</Text>
    <Text style={styles.tradeCardType}>{card.type}</Text>
    {onRemove && (
      <TouchableOpacity onPress={() => onRemove(card)} style={styles.removeCardBtn}>
        <Ionicons name="close" size={14} color={COLORS.danger} />
      </TouchableOpacity>
    )}
  </View>
);

// ── Trade list item ───────────────────────────────────────────────────────────
const TradeListItem = ({ trade, onPress, onDelete }) => {
  const meetup = trade.meetupDate ? new Date(trade.meetupDate) : null;
  const isToday = meetup && meetup.toDateString() === new Date().toDateString();
  const isPast = meetup && meetup < new Date();

  return (
    <TouchableOpacity style={styles.tradeItem} onPress={onPress} activeOpacity={0.8}>
      <LinearGradient colors={[COLORS.bgCard, COLORS.bg]} style={styles.tradeItemGrad}>
        <View style={styles.tradeItemHeader}>
          <View style={styles.tradeItemLeft}>
            <Ionicons name="person-circle-outline" size={28} color={COLORS.arcaneBright} />
            <View>
              <Text style={styles.tradeItemName}>{trade.traderName}</Text>
              <Text style={styles.tradeItemCount}>{trade.cards.length} card{trade.cards.length !== 1 ? 's' : ''}</Text>
            </View>
          </View>
          <View style={styles.tradeItemRight}>
            <StatusBadge status={trade.status} />
            <TouchableOpacity onPress={() => onDelete(trade)} style={styles.deleteBtn}>
              <Ionicons name="trash-outline" size={16} color={COLORS.danger} />
            </TouchableOpacity>
          </View>
        </View>

        {meetup && (
          <View style={styles.tradeItemMeta}>
            <Ionicons name="calendar-outline" size={13} color={isToday ? COLORS.goldLight : COLORS.textMuted} />
            <Text style={[styles.tradeItemDate, isToday && { color: COLORS.goldLight }]}>
              {isToday ? 'TODAY' : meetup.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric', year: 'numeric' })}
              {trade.meetupTime ? ` · ${trade.meetupTime}` : ''}
            </Text>
          </View>
        )}
        {trade.meetupPlace && (
          <View style={styles.tradeItemMeta}>
            <Ionicons name="location-outline" size={13} color={COLORS.textMuted} />
            <Text style={styles.tradeItemMetaText}>{trade.meetupPlace}</Text>
          </View>
        )}
        {trade.notes && (
          <View style={styles.tradeItemMeta}>
            <Ionicons name="document-text-outline" size={13} color={COLORS.textMuted} />
            <Text style={styles.tradeItemMetaText} numberOfLines={1}>{trade.notes}</Text>
          </View>
        )}
      </LinearGradient>
    </TouchableOpacity>
  );
};

// ── Date/Time input helpers ───────────────────────────────────────────────────
const DateInput = ({ label, value, onChange }) => (
  <View style={styles.inputGroup}>
    <Text style={styles.inputLabel}>{label}</Text>
    <TextInput
      style={styles.input}
      value={value}
      onChangeText={onChange}
      placeholder="YYYY-MM-DD"
      placeholderTextColor={COLORS.textMuted}
    />
  </View>
);

const TimeInput = ({ label, value, onChange }) => (
  <View style={styles.inputGroup}>
    <Text style={styles.inputLabel}>{label}</Text>
    <TextInput
      style={styles.input}
      value={value}
      onChangeText={onChange}
      placeholder="HH:MM (e.g. 14:30)"
      placeholderTextColor={COLORS.textMuted}
    />
  </View>
);

// ── Main Screen ───────────────────────────────────────────────────────────────
export default function TradesScreen() {
  const [trades, setTrades] = useState([]);
  const [selectedTrade, setSelectedTrade] = useState(null);
  const [showForm, setShowForm] = useState(false);
  const [browsing, setBrowsing] = useState(false);
  const [filterStatus, setFilterStatus] = useState('');

  // Form state
  const [traderName, setTraderName] = useState('');
  const [meetupDate, setMeetupDate] = useState('');
  const [meetupTime, setMeetupTime] = useState('');
  const [meetupPlace, setMeetupPlace] = useState('');
  const [notes, setNotes] = useState('');
  const [tradeCards, setTradeCards] = useState([]);
  const [editingTrade, setEditingTrade] = useState(null);

  useEffect(() => { loadTrades(); }, []);

  const loadTrades = async () => {
    const t = await getTrades();
    setTrades(t);
  };

  const openNewTrade = () => {
    setEditingTrade(null);
    setTraderName('');
    setMeetupDate('');
    setMeetupTime('');
    setMeetupPlace('');
    setNotes('');
    setTradeCards([]);
    setShowForm(true);
  };

  const openEditTrade = (trade) => {
    setEditingTrade(trade);
    setTraderName(trade.traderName);
    setMeetupDate(trade.meetupDate || '');
    setMeetupTime(trade.meetupTime || '');
    setMeetupPlace(trade.meetupPlace || '');
    setNotes(trade.notes || '');
    setTradeCards(trade.cards || []);
    setSelectedTrade(null);
    setShowForm(true);
  };

  const saveTrade = async () => {
    if (!traderName.trim()) {
      Alert.alert('Missing info', 'Please enter the trader\'s name.');
      return;
    }

    // Build meetup datetime
    let meetupDateTime = null;
    if (meetupDate) {
      const timeStr = meetupTime || '12:00';
      meetupDateTime = new Date(`${meetupDate}T${timeStr}:00`).toISOString();
    }

    // Cancel old notification if editing
    if (editingTrade?.notificationId) {
      await cancelTradeNotification(editingTrade.notificationId);
    }

    const trade = {
      id: editingTrade?.id || Date.now().toString(),
      traderName: traderName.trim(),
      meetupDate: meetupDateTime,
      meetupTime: meetupTime || '',
      meetupPlace: meetupPlace.trim(),
      notes: notes.trim(),
      cards: tradeCards,
      status: editingTrade?.status || 'upcoming',
      createdAt: editingTrade?.createdAt || new Date().toISOString(),
      notificationId: null,
    };

    // Schedule reminder
    const hasPermission = await requestNotificationPermission();
    if (hasPermission && meetupDateTime) {
      const notifId = await scheduleTradReminder(trade);
      trade.notificationId = notifId;
      if (notifId) {
        Alert.alert('⏰ Reminder Set', 'You\'ll get a notification 1 day before the meetup!');
      }
    }

    const all = await getTrades();
    const idx = all.findIndex(t => t.id === trade.id);
    if (idx >= 0) all[idx] = trade;
    else all.unshift(trade);
    await saveTrades(all);
    setTrades(all);
    setShowForm(false);
  };

  const updateStatus = async (trade, status) => {
    const all = await getTrades();
    const updated = all.map(t => t.id === trade.id ? { ...t, status } : t);
    await saveTrades(updated);
    setTrades(updated);
    setSelectedTrade(prev => prev ? { ...prev, status } : null);
  };

  const deleteTrade = async (trade) => {
    Alert.alert('Delete Trade', `Delete trade with ${trade.traderName}?`, [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Delete', style: 'destructive', onPress: async () => {
          if (trade.notificationId) await cancelTradeNotification(trade.notificationId);
          const all = await getTrades();
          const filtered = all.filter(t => t.id !== trade.id);
          await saveTrades(filtered);
          setTrades(filtered);
          setSelectedTrade(null);
        }
      }
    ]);
  };

  const addCardToTrade = (card) => {
    if (tradeCards.find(c => c.id === card.id)) {
      Alert.alert('Already added', 'This card is already in the trade list.');
      return;
    }
    setTradeCards(prev => [...prev, card]);
    setBrowsing(false);
  };

  const removeCardFromTrade = (card) => {
    setTradeCards(prev => prev.filter(c => c.id !== card.id));
  };

  const filteredTrades = filterStatus ? trades.filter(t => t.status === filterStatus) : trades;

  // Card browse overlay
  if (browsing) {
    return (
      <View style={{ flex: 1 }}>
        <View style={styles.browseHeader}>
          <TouchableOpacity style={styles.backBtn} onPress={() => setBrowsing(false)}>
            <Ionicons name="arrow-back" size={20} color={COLORS.textPrimary} />
            <Text style={styles.backBtnText}>Back to Trade</Text>
          </TouchableOpacity>
          <Text style={styles.browseHint}>Tap a card then "Add to Deck"</Text>
        </View>
        <CardsScreen onAddToDeck={addCardToTrade} />
      </View>
    );
  }

  // Trade detail view
  if (selectedTrade) {
    const meetup = selectedTrade.meetupDate ? new Date(selectedTrade.meetupDate) : null;
    return (
      <SafeAreaView style={styles.safe}>
        <View style={styles.detailHeader}>
          <TouchableOpacity onPress={() => setSelectedTrade(null)} style={styles.backBtn}>
            <Ionicons name="arrow-back" size={20} color={COLORS.textPrimary} />
          </TouchableOpacity>
          <Text style={styles.detailTitle} numberOfLines={1}>Trade with {selectedTrade.traderName}</Text>
          <TouchableOpacity style={styles.iconBtn} onPress={() => openEditTrade(selectedTrade)}>
            <Ionicons name="pencil-outline" size={18} color={COLORS.textSecondary} />
          </TouchableOpacity>
        </View>

        <ScrollView contentContainerStyle={styles.detailContent}>
          <StatusBadge status={selectedTrade.status} />

          <View style={styles.detailSection}>
            <Text style={styles.detailSectionTitle}>TRADER</Text>
            <View style={styles.detailRow}>
              <Ionicons name="person-outline" size={16} color={COLORS.arcaneBright} />
              <Text style={styles.detailRowText}>{selectedTrade.traderName}</Text>
            </View>
          </View>

          {(meetup || selectedTrade.meetupPlace) && (
            <View style={styles.detailSection}>
              <Text style={styles.detailSectionTitle}>MEETUP</Text>
              {meetup && (
                <View style={styles.detailRow}>
                  <Ionicons name="calendar-outline" size={16} color={COLORS.arcaneBright} />
                  <Text style={styles.detailRowText}>
                    {meetup.toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' })}
                    {selectedTrade.meetupTime ? ` at ${selectedTrade.meetupTime}` : ''}
                  </Text>
                </View>
              )}
              {selectedTrade.meetupPlace && (
                <View style={styles.detailRow}>
                  <Ionicons name="location-outline" size={16} color={COLORS.arcaneBright} />
                  <Text style={styles.detailRowText}>{selectedTrade.meetupPlace}</Text>
                </View>
              )}
            </View>
          )}

          {selectedTrade.notes && (
            <View style={styles.detailSection}>
              <Text style={styles.detailSectionTitle}>NOTES</Text>
              <Text style={styles.notesText}>{selectedTrade.notes}</Text>
            </View>
          )}

          <View style={styles.detailSection}>
            <Text style={styles.detailSectionTitle}>CARDS ({selectedTrade.cards.length})</Text>
            {selectedTrade.cards.length === 0 ? (
              <Text style={styles.emptyText}>No cards added</Text>
            ) : (
              selectedTrade.cards.map(card => (
                <TradeCardItem key={card.id} card={card} />
              ))
            )}
          </View>

          {selectedTrade.status === 'upcoming' && (
            <View style={styles.statusBtns}>
              <TouchableOpacity style={styles.completedBtn} onPress={() => updateStatus(selectedTrade, 'completed')}>
                <Ionicons name="checkmark-circle-outline" size={18} color={COLORS.win} />
                <Text style={[styles.statusBtnText, { color: COLORS.win }]}>Mark Completed</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.cancelledBtn} onPress={() => updateStatus(selectedTrade, 'cancelled')}>
                <Ionicons name="close-circle-outline" size={18} color={COLORS.danger} />
                <Text style={[styles.statusBtnText, { color: COLORS.danger }]}>Cancel Trade</Text>
              </TouchableOpacity>
            </View>
          )}
        </ScrollView>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.safe}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>TRADES</Text>
        <TouchableOpacity style={styles.newBtn} onPress={openNewTrade}>
          <Ionicons name="add" size={18} color={COLORS.textPrimary} />
          <Text style={styles.newBtnText}>New Trade</Text>
        </TouchableOpacity>
      </View>

      {/* Filter tabs */}
      <View style={styles.filterRow}>
        {['', 'upcoming', 'completed', 'cancelled'].map(status => (
          <TouchableOpacity
            key={status}
            style={[styles.filterTab, filterStatus === status && styles.filterTabActive]}
            onPress={() => setFilterStatus(status)}
          >
            <Text style={[styles.filterTabText, filterStatus === status && styles.filterTabTextActive]}>
              {status === '' ? 'All' : status.charAt(0).toUpperCase() + status.slice(1)}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* Trade list */}
      <FlatList
        data={filteredTrades}
        keyExtractor={item => item.id}
        contentContainerStyle={styles.list}
        renderItem={({ item }) => (
          <TradeListItem
            trade={item}
            onPress={() => setSelectedTrade(item)}
            onDelete={deleteTrade}
          />
        )}
        ListEmptyComponent={
          <View style={styles.emptyState}>
            <Ionicons name="swap-horizontal-outline" size={48} color={COLORS.textMuted} />
            <Text style={styles.emptyTitle}>No Trades Yet</Text>
            <Text style={styles.emptySubtitle}>Schedule a card trade with another player</Text>
            <TouchableOpacity style={styles.emptyCreateBtn} onPress={openNewTrade}>
              <Text style={styles.emptyCreateBtnText}>Schedule Trade</Text>
            </TouchableOpacity>
          </View>
        }
      />

      {/* New / Edit Trade Modal */}
      <Modal visible={showForm} animationType="slide" onRequestClose={() => setShowForm(false)}>
        <SafeAreaView style={styles.formSafe}>
          <View style={styles.formHeader}>
            <TouchableOpacity onPress={() => setShowForm(false)}>
              <Ionicons name="close" size={24} color={COLORS.textSecondary} />
            </TouchableOpacity>
            <Text style={styles.formTitle}>{editingTrade ? 'EDIT TRADE' : 'NEW TRADE'}</Text>
            <TouchableOpacity onPress={saveTrade} style={styles.saveBtn}>
              <Text style={styles.saveBtnText}>Save</Text>
            </TouchableOpacity>
          </View>

          <ScrollView contentContainerStyle={styles.formContent}>
            {/* Trader name */}
            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>TRADER NAME *</Text>
              <TextInput
                style={styles.input}
                value={traderName}
                onChangeText={setTraderName}
                placeholder="Who are you trading with?"
                placeholderTextColor={COLORS.textMuted}
                autoFocus
              />
            </View>

            {/* Meetup details */}
            <Text style={styles.sectionHeader}>MEETUP DETAILS</Text>

            <DateInput label="DATE" value={meetupDate} onChange={setMeetupDate} />
            <TimeInput label="TIME" value={meetupTime} onChange={setMeetupTime} />

            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>PLACE</Text>
              <TextInput
                style={styles.input}
                value={meetupPlace}
                onChangeText={setMeetupPlace}
                placeholder="Where are you meeting?"
                placeholderTextColor={COLORS.textMuted}
              />
            </View>

            {/* Notes */}
            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>NOTES</Text>
              <TextInput
                style={[styles.input, styles.inputMultiline]}
                value={notes}
                onChangeText={setNotes}
                placeholder="Agreed price, card conditions, anything else..."
                placeholderTextColor={COLORS.textMuted}
                multiline
                numberOfLines={4}
              />
            </View>

            {/* Reminder info */}
            {meetupDate && (
              <View style={styles.reminderInfo}>
                <Ionicons name="notifications-outline" size={14} color={COLORS.arcaneBright} />
                <Text style={styles.reminderInfoText}>
                  You'll be reminded 1 day before the meetup
                </Text>
              </View>
            )}

            {/* Cards */}
            <Text style={styles.sectionHeader}>CARDS IN TRADE</Text>
            {tradeCards.length === 0 ? (
              <Text style={styles.emptyText}>No cards added yet</Text>
            ) : (
              tradeCards.map(card => (
                <TradeCardItem key={card.id} card={card} onRemove={removeCardFromTrade} />
              ))
            )}

            <TouchableOpacity style={styles.addCardsBtn} onPress={() => setBrowsing(true)}>
              <LinearGradient colors={[COLORS.arcane, COLORS.arcaneBright]} style={styles.addCardsBtnGrad}>
                <Ionicons name="add" size={18} color={COLORS.textPrimary} />
                <Text style={styles.addCardsBtnText}>Browse & Add Cards</Text>
              </LinearGradient>
            </TouchableOpacity>
          </ScrollView>
        </SafeAreaView>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: COLORS.bg },
  header: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    padding: SPACING.md, borderBottomWidth: 1, borderBottomColor: COLORS.border,
  },
  headerTitle: { fontSize: 16, fontWeight: '800', color: COLORS.goldLight, letterSpacing: 4 },
  newBtn: {
    flexDirection: 'row', alignItems: 'center', gap: SPACING.xs,
    backgroundColor: COLORS.arcane, paddingHorizontal: SPACING.md,
    paddingVertical: SPACING.sm, borderRadius: RADIUS.md,
  },
  newBtnText: { color: COLORS.textPrimary, fontWeight: '700', fontSize: 13 },

  filterRow: {
    flexDirection: 'row', paddingHorizontal: SPACING.md, paddingVertical: SPACING.sm,
    gap: SPACING.xs, borderBottomWidth: 1, borderBottomColor: COLORS.border,
  },
  filterTab: {
    paddingHorizontal: SPACING.sm, paddingVertical: 5,
    borderRadius: RADIUS.full, borderWidth: 1, borderColor: COLORS.border,
  },
  filterTabActive: { backgroundColor: COLORS.arcane, borderColor: COLORS.arcaneBright },
  filterTabText: { fontSize: 11, color: COLORS.textMuted, fontWeight: '600' },
  filterTabTextActive: { color: COLORS.textPrimary },

  list: { padding: SPACING.md, gap: SPACING.sm, paddingBottom: 80 },

  tradeItem: { borderRadius: RADIUS.md, overflow: 'hidden', borderWidth: 1, borderColor: COLORS.border },
  tradeItemGrad: { padding: SPACING.md },
  tradeItemHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: SPACING.sm },
  tradeItemLeft: { flexDirection: 'row', alignItems: 'center', gap: SPACING.sm },
  tradeItemRight: { flexDirection: 'row', alignItems: 'center', gap: SPACING.sm },
  tradeItemName: { fontSize: 16, fontWeight: '700', color: COLORS.textPrimary },
  tradeItemCount: { fontSize: 12, color: COLORS.textMuted },
  tradeItemMeta: { flexDirection: 'row', alignItems: 'center', gap: SPACING.xs, marginTop: 3 },
  tradeItemDate: { fontSize: 12, color: COLORS.textMuted },
  tradeItemMetaText: { fontSize: 12, color: COLORS.textMuted, flex: 1 },
  deleteBtn: { padding: SPACING.xs },

  statusBadge: {
    paddingHorizontal: SPACING.sm, paddingVertical: 3,
    borderRadius: RADIUS.full, borderWidth: 1, alignSelf: 'flex-start',
  },
  statusText: { fontSize: 9, fontWeight: '800', letterSpacing: 1.5 },

  // Detail view
  detailHeader: {
    flexDirection: 'row', alignItems: 'center', padding: SPACING.md,
    borderBottomWidth: 1, borderBottomColor: COLORS.border, gap: SPACING.sm,
  },
  detailTitle: { flex: 1, fontSize: 16, fontWeight: '700', color: COLORS.textPrimary },
  iconBtn: {
    width: 36, height: 36, borderRadius: RADIUS.sm,
    backgroundColor: COLORS.bgCard, justifyContent: 'center', alignItems: 'center',
    borderWidth: 1, borderColor: COLORS.border,
  },
  detailContent: { padding: SPACING.md, gap: SPACING.md, paddingBottom: 60 },
  detailSection: {
    backgroundColor: COLORS.bgCard, borderRadius: RADIUS.md,
    padding: SPACING.md, borderWidth: 1, borderColor: COLORS.border,
  },
  detailSectionTitle: { fontSize: 10, color: COLORS.textMuted, letterSpacing: 2, marginBottom: SPACING.sm },
  detailRow: { flexDirection: 'row', alignItems: 'center', gap: SPACING.sm, marginBottom: SPACING.xs },
  detailRowText: { fontSize: 15, color: COLORS.textPrimary, flex: 1 },
  notesText: { fontSize: 14, color: COLORS.textSecondary, lineHeight: 22 },
  statusBtns: { gap: SPACING.sm },
  completedBtn: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: SPACING.xs,
    padding: SPACING.md, borderRadius: RADIUS.md,
    borderWidth: 1, borderColor: COLORS.win, backgroundColor: COLORS.win + '15',
  },
  cancelledBtn: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: SPACING.xs,
    padding: SPACING.md, borderRadius: RADIUS.md,
    borderWidth: 1, borderColor: COLORS.danger, backgroundColor: COLORS.danger + '15',
  },
  statusBtnText: { fontWeight: '700', fontSize: 14 },

  // Trade card items
  tradeCardItem: {
    flexDirection: 'row', alignItems: 'center', gap: SPACING.sm,
    backgroundColor: COLORS.bgElevated, padding: SPACING.sm,
    borderRadius: RADIUS.sm, borderWidth: 1, borderColor: COLORS.border, marginBottom: 4,
  },
  tradeCardDot: { width: 8, height: 8, borderRadius: 4 },
  tradeCardName: { flex: 1, fontSize: 14, color: COLORS.textPrimary, fontWeight: '600' },
  tradeCardType: { fontSize: 11, color: COLORS.textMuted },
  removeCardBtn: { padding: 4 },

  // Form
  formSafe: { flex: 1, backgroundColor: COLORS.bg },
  formHeader: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    padding: SPACING.md, borderBottomWidth: 1, borderBottomColor: COLORS.border,
  },
  formTitle: { fontSize: 14, fontWeight: '800', color: COLORS.goldLight, letterSpacing: 4 },
  saveBtn: { backgroundColor: COLORS.arcane, paddingHorizontal: SPACING.md, paddingVertical: SPACING.sm, borderRadius: RADIUS.sm },
  saveBtnText: { color: COLORS.textPrimary, fontWeight: '700' },
  formContent: { padding: SPACING.md, gap: SPACING.sm, paddingBottom: 60 },

  sectionHeader: {
    fontSize: 10, color: COLORS.textMuted, letterSpacing: 2,
    marginTop: SPACING.md, marginBottom: SPACING.xs,
  },
  inputGroup: { gap: SPACING.xs },
  inputLabel: { fontSize: 10, color: COLORS.textMuted, letterSpacing: 2 },
  input: {
    backgroundColor: COLORS.bgInput, color: COLORS.textPrimary,
    borderRadius: RADIUS.sm, padding: SPACING.md,
    borderWidth: 1, borderColor: COLORS.border, fontSize: 15,
  },
  inputMultiline: { height: 100, textAlignVertical: 'top' },

  reminderInfo: {
    flexDirection: 'row', alignItems: 'center', gap: SPACING.xs,
    backgroundColor: COLORS.arcane + '20', padding: SPACING.sm,
    borderRadius: RADIUS.sm, borderWidth: 1, borderColor: COLORS.arcane + '40',
  },
  reminderInfoText: { fontSize: 12, color: COLORS.arcaneBright },

  addCardsBtn: { borderRadius: RADIUS.md, overflow: 'hidden', marginTop: SPACING.sm },
  addCardsBtnGrad: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center',
    gap: SPACING.xs, padding: SPACING.md,
  },
  addCardsBtnText: { color: COLORS.textPrimary, fontWeight: '700' },

  emptyState: { alignItems: 'center', padding: SPACING.xxl },
  emptyTitle: { fontSize: 18, color: COLORS.textSecondary, marginTop: SPACING.md, fontWeight: '600' },
  emptySubtitle: { fontSize: 13, color: COLORS.textMuted, marginTop: SPACING.sm, textAlign: 'center' },
  emptyCreateBtn: {
    marginTop: SPACING.lg, backgroundColor: COLORS.arcane,
    paddingHorizontal: SPACING.xl, paddingVertical: SPACING.md, borderRadius: RADIUS.md,
  },
  emptyCreateBtnText: { color: COLORS.textPrimary, fontWeight: '700' },
  emptyText: { fontSize: 13, color: COLORS.textMuted, fontStyle: 'italic', marginBottom: SPACING.sm },

  backBtn: { flexDirection: 'row', alignItems: 'center', gap: SPACING.xs },
  backBtnText: { color: COLORS.textPrimary, fontSize: 15 },
  browseHeader: {
    backgroundColor: COLORS.bgCard, padding: SPACING.md,
    borderBottomWidth: 1, borderBottomColor: COLORS.border,
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
  },
  browseHint: { fontSize: 11, color: COLORS.textMuted },
});
